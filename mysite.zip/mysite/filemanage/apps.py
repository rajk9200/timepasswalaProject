from django.apps import AppConfig


class FilemanageConfig(AppConfig):
    name = 'filemanage'
