from django.shortcuts import render,HttpResponse
from .models import Posts,likePost,Chat
from .forms import PostForm
from accounts.models import Signup,UserProfile

from authy.api import AuthyApiClient
from django.conf import settings
from django.shortcuts import render, redirect



from django.db.models import Q
# Create your views here.

from django.contrib import messages
def all_posts(request):
    if not request.session.get('email'):
        return redirect('login')
    login_user = request.session.get('email')

    user_auth = Signup.objects.get(email=login_user)


        # login_user = request.session.get('email')
        # likeid=1
        # user = Signup.objects.get(email=login_user)
        # post = Posts.objects.get(id=likebtn)
        #
        # likePost.objects.create(like=likeid,user=user,post=post)
        # messages.success(request,'like ho gya')
        # print("like ho gya")

    user_profile=None
    form =PostForm(request.POST or None, request.FILES or None)
    if form.is_valid():

        title=form.cleaned_data.get('title')
        image=form.cleaned_data.get('image')



        print(user_auth)

        post = Posts(user=user_auth, title=title, image=image)
        post.save()

    user_profile = UserProfile.objects.get(user=user_auth)
    posts=Posts.objects.all()

    users = UserProfile.objects.all()

    lk =likePost.objects.all()
    # temp =0
    # for i in lk:
    #     temp=temp+int(i)
    #
    # print(temp)
    print(lk)



    context={
        'form':form,
        'posts':posts,
        'user_profile':user_profile,
        'lk':lk,
        'users':users
    }
    return render(request, 'posts.html',context)






def likepost(request,id=None):

    post_obj =Posts.objects.get(id=id)

    login_user = request.session.get('email')

    like_id =1
    user_auth = Signup.objects.get(email=login_user)

    likePost.objects.create(user=user_auth,post=post_obj,like=like_id)


    p =Posts.objects.get(id=id)
    lkc =int(p.like)+1
    print('kkk',lkc)
    Posts.objects.filter(id=id).update(like=lkc)
    messages.success(request,"One Like")
    return redirect('all_posts')





def friends_chat(request):
    ch =Chat.objects.all().order_by('-id')
    if request.method== 'POST':
        mes =request.POST.get('mes')

        login_user = request.session.get('email')
        user_auth = Signup.objects.get(email=login_user)
        us =UserProfile.objects.get(user=user_auth)
        chat =Chat.objects.create(user=us,message=mes)
        if chat:
            print('dd')
            return redirect('chat')

    context ={
        'ch':ch
    }
    return render(request,'chat.html',context)