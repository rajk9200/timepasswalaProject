from django.urls import path,include
from . import views
urlpatterns=[
    path('',views.all_posts, name='all_posts'),
    path('chat/',views.friends_chat, name='chat'),


    path('like/<int:id>/',views.likepost, name='like'),



]