b833b0ede9f845483169ed7defc054d3---  Auth_Sid



ACb908b10f16d86f5bca10793b231dd714 --  Acount




verification = authy_api.phones.verification_check(
                request.session['phone_number'],
                request.session['country_code'],
                form.cleaned_data['token']

            )
            if verification.ok():
                request.session['is_verified'] = True
                return redirect('verified')
            else:
                for error_msg in verification.errors().values():
                    form.add_error(None, error_msg)