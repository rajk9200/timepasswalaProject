from django.contrib import admin
from .models import Posts,likePost,Chat
# Register your models here.
admin.site.register(Posts)
admin.site.register(likePost)
admin.site.register(Chat)